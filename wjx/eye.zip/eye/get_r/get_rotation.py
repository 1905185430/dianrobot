'''
输入：手的rgb图片  用于得到食指和拇指的mask
     深度图       用于计算食指和手指形成的平面
'''

import cv2
import mediapipe as mp
import numpy as np

# 初始化 Mediapipe Hands，单图片模式
mp_hands = mp.solutions.hands
hands = mp_hands.Hands(
    static_image_mode=True,      # 单图片模式
    max_num_hands=2,             # 最多检测2只手
    model_complexity=1,
    min_detection_confidence=0.5
)

# 绘图工具
mp_drawing = mp.solutions.drawing_utils
mp_drawing_styles = mp.solutions.drawing_styles

# 读取图片
img_path = '/home/xuan/dianrobot/dianrobot/wjx/eye/get_r/hand_capture_rgb.png'
image = cv2.imread(img_path)
if image is None:
    print("图片读取失败")
    exit()

# Mediapipe 处理
results = hands.process(cv2.cvtColor(image, cv2.COLOR_BGR2RGB))
canvas = image.copy()
img_width, img_height = image.shape[1], image.shape[0]

if results.multi_hand_landmarks:
    for hand_landmarks in results.multi_hand_landmarks:
        # 绘制关键点和连接线
        mp_drawing.draw_landmarks(
            canvas,
            hand_landmarks,
            mp_hands.HAND_CONNECTIONS,
            mp_drawing_styles.get_default_hand_landmarks_style(),
            mp_drawing_styles.get_default_hand_connections_style()
        )
        # 绘制关键点编号
        for idx, lm in enumerate(hand_landmarks.landmark):
            px = int(lm.x * img_width)
            py = int(lm.y * img_height)
            cv2.putText(canvas, str(idx), (px-10, py+10),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 1)
    cv2.imshow('Hand Landmarks', canvas)
    cv2.waitKey(0)
    cv2.destroyAllWindows()
else:
    print("未检测到手掌关键点")